#!/usr/bin/env bash
java -cp "xmlmate.jar:subjects/jeuclid/jeuclid.jar" org.evosuite.xml.XMLTestSuiteGenerator -s schemas/mathml3.xsd -r {http://www.w3.org/1998/Math/MathML}math -p net.sourceforge.jeuclid  -c net.sourceforge.jeuclid.Driver -t 60
