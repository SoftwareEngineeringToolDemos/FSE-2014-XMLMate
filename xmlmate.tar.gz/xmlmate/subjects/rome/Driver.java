package com.sun.syndication;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.SyndFeedOutput;
import com.sun.syndication.io.XmlReader;

public class Driver {
	static String[]		feedTypes	= { "atom_0.3", "rss_2.0", "rss_1.0", "rss_0.94", "rss_0.93", "rss_0.92", "rss_0.9" };
	static OutputStream	nopStream	= new OutputStream() {
		@Override
		public void write(int arg0) throws IOException {
			// nop
		}
	};

	public static void main(String[] args) throws FeedException, IOException {
		if (args.length < 1) {
			System.out.println("Usage: <path-to-xml>+");
			return;
		}
		//		int i = 0;
		for (String arg : args) {
			// System.out.println("" + ++i + "/" + args.length + "\t" + arg);
			// System.out.println("Reading " + arg);
			SyndFeedInput input = new SyndFeedInput();
			SyndFeed feed = input.build(new XmlReader(new File(arg)));
			SyndFeedOutput output = new SyndFeedOutput();
			for (String feedType : feedTypes) {
				feed.setFeedType(feedType);
				/* test getters */
				testGetters(feed);
				/* test conversion */
				testConversion(output, feed);
			}
		}
	}

	private static void testGetters(SyndFeed feed) {
		feed.getAuthor();
		feed.getAuthors();
		feed.getCategories();
		feed.getContributors();
		feed.getCopyright();
		feed.getDescription();
		feed.getDescriptionEx();
		feed.getEncoding();
		feed.getEntries();
		feed.getEntries();
		feed.getFeedType();
		feed.getForeignMarkup();
		feed.getImage();
		feed.getInterface();
		feed.getLanguage();
		feed.getLink();
		feed.getLinks();
		feed.getModules();
		feed.getPublishedDate();
		feed.getSupportedFeedTypes();
		feed.getTitle();
		feed.getTitleEx();
		feed.getUri();
	}

	private static void testConversion(SyndFeedOutput output, SyndFeed feed) throws IOException, FeedException {
		output.output(feed, new PrintWriter(nopStream), false);
		output.output(feed, new PrintWriter(nopStream), true);
		output.outputString(feed, false);
		output.outputString(feed, true);
		output.outputJDom(feed);
		output.outputW3CDom(feed);
	}
}
