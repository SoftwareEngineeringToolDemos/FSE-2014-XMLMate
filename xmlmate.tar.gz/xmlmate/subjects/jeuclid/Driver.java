package net.sourceforge.jeuclid;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import net.sourceforge.jeuclid.context.LayoutContextImpl;
import net.sourceforge.jeuclid.context.Parameter;
import net.sourceforge.jeuclid.converter.Converter;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class Driver {
	private final static HashMap<String, String>	formats	= new HashMap<String, String>();
	private final static MutableLayoutContext	params	= new LayoutContextImpl(LayoutContextImpl.getDefaultLayoutContext());
	private final static OutputStream		nopstream = new OutputStream() {
		@Override
		public void write(int arg0) throws IOException {
			/* nop */
		}
	};

	static {
		params.setParameter(Parameter.MATHSIZE, 25f);
		formats.put("image/png", "png");
		formats.put("image/svg+xml", "svg");
		formats.put("application/pdf", "pdf");
	}

	public static void main(String[] args) throws IOException, SAXException {
		if (args.length < 1) {
			System.out.println("Usage: <path-to-xml>+");
			return;
		}

		for (String arg : args) {
			Document doc = MathMLParserSupport.parseFile(new File(arg));
			// test image rendering
			Converter.getInstance().render(doc, params);
			// test format conversion
			for (String mime : formats.keySet())
				Converter.getInstance().convert(doc, nopstream, mime, params);
		}
	}
}
