#!/usr/bin/env bash
java -cp "xmlmate.jar:subjects/rome/rome.jar" org.evosuite.xml.XMLTestSuiteGenerator -s schemas/atom.xsd -r {http://www.w3.org/2005/Atom}feed -p com.sun.syndication -c com.sun.syndication.Driver -t 60
