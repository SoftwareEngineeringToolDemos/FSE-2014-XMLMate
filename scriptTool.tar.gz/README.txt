XMLMate - Evolutionary XML Test Generation 
Paper: FSE 2014
Authors: Nikolas Havrikov, Andreas Zeller, Juan Pablo Galeotti, Matthias Hoschele


Using XMLMate -

Step 1 - Goto the directory XMLMate on the Desktop
          
Step 2 - double click on usage-example-freedots.sh and select 'Run in terminal.'
           * This will start the execution of program.

Step 3 - After the program finishes execution(roughly 1-2 min), a folder named 'out' will be created which will contain the generated test 		 input xmls.
	   * This folder will contain a folder with a name freedots+timestamp which will have all the generated input xmls.

Step 4 - To see a merge report double click on buildScript.sh This will create a 'report' directory which will contain all the merged report.
 	   * This will contain a index.html file which will open in browser to show a merged coverage report.


Demo on Youtube:  https://www.youtube.com/watch?v=-yKom5mbft0

Note: Since source code was not provided for this tool and for the demo test project, the eclipse plugin to show the result of execution is not included.(This was not covered in the paper)


