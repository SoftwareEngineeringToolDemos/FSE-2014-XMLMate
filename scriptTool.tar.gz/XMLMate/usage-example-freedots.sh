#!/usr/bin/env bash
java -cp "xmlmate.jar:subjects/freedots/freedots.jar" org.evosuite.xml.XMLTestSuiteGenerator -s schemas/musicxml.xsd -r score-partwise -p freedots -c freedots.Driver -t 60
