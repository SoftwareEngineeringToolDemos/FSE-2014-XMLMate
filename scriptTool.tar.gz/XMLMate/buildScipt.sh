#!/usr/bin/env bash
fname= ls ./out -t | head -n1
ant -Deval.testdriver=subjects/freedots/freedots.jar -Deval.target.dir=out/$fname coverage merge report
