package freedots;

public class Driver {
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: <path-to-xml>+");
			return;
		}
		for (String arg : args) {
			String[] params = { "-nw", arg }; // don't play back the file, just transcribe it
			Main.main(params);
		}
	}
}
